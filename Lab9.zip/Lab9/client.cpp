// #include <iostream>
// #include "SpellChecker.h"

// int main()
// {
//     SpellChecker sc = SpellChecker("./dictionary.txt");
//     sc.checkSpelling("./dummy.txt");
//     std::cout << sc.countWordsBeginWith("app") << std::endl;
//     return 0;
// }

#include <vector>
#include <algorithm>
int main()
{
    int a;
    std::vector< std::vector <int> > v;
    std::vector< std::vector <int> >::const_iterator it = std::find( v.begin(), v.end(), a );
}